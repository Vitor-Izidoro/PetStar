import React from "react";
import Input from "../../components/Form/Input";
import Select from "../../components/Form/Select";
import CheckboxGroup from "../../components/Form/CheckBocGroup";

const FiltersCaregiversList = ({
  location,
  setLocation,
  service,
  setService,
  maxPrice,
  setMaxPrice,
  minRating,
  setMinRating,
  petTypes,
  setPetTypes,
  features,
  setFeatures,
  toggleArrayValue,
}) => {
  return (
    <aside className="lg:col-span-1 bg-white rounded-xl shadow p-6 h-fit">
      <h5 className="font-bold text-gray-800 mb-4">Filtros</h5>

      {/* Localização */}
      <Input
        label="Localização"
        value={location}
        onChange={(e) => setLocation(e.target.value)}
        placeholder="Cidade ou bairro"
      />

      {/* Serviço */}
      <Select
        label="Tipo de serviço"
        value={service}
        onChange={(e) => setService(e.target.value)}
        options={[
          { value: "Todos", label: "Todos os serviços" },
          { value: "Hospedagem", label: "Hospedagem" },
          { value: "Creche", label: "Creche" },
          { value: "Passeio", label: "Passeio" },
          { value: "Visita", label: "Visita" },
        ]}
      />

      {/* Preço */}
      <Input
        label="Preço por noite"
        type="range"
        value={maxPrice}
        onChange={(e) => setMaxPrice(Number(e.target.value))}
        min={0}
        max={100}
        step={5}
      />
      <div className="flex justify-between text-sm text-gray-600 mb-4">
        <span>R$ 0</span>
        <span>R$ {maxPrice}+</span>
      </div>

      {/* Avaliação */}
      <Select
        label="Avaliação mínima"
        value={minRating}
        onChange={(e) => setMinRating(Number(e.target.value))}
        options={[
          { value: 0, label: "Qualquer avaliação" },
          { value: 3, label: "3.0+ ★" },
          { value: 3.5, label: "3.5+ ★" },
          { value: 4, label: "4.0+ ★" },
          { value: 4.5, label: "4.5+ ★" },
        ]}
      />

      {/* Tipo de pet */}
      <CheckboxGroup
        label="Tipo de pet"
        options={[
          { value: "Cachorros", label: "Cachorros" },
          { value: "Gatos", label: "Gatos" },
          { value: "Outros", label: "Outros" },
        ]}
        selectedValues={petTypes}
        onChange={(val) => toggleArrayValue(petTypes, val, setPetTypes)}
      />

      {/* Características */}
      <CheckboxGroup
        label="Características"
        options={[
          { value: "Quintal", label: "Quintal" },
          { value: "Experiência veterinária", label: "Experiência veterinária" },
          { value: "Administra medicamentos", label: "Administra medicamentos" },
        ]}
        selectedValues={features}
        onChange={(val) => toggleArrayValue(features, val, setFeatures)}
      />
    </aside>
  );
};

export default FiltersCaregiversList;
